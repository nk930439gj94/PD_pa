Environment:
    edaU1 CentOS 6.5
    compile by c++11
compile:
    make
run:
    ./a1
    ./a2
    ./a3
    ./a4
    ./a5
    ./n1
    ./n2
    ./n3
    ./all   // for all above
remove executable, .o:
    make clean