Environment:
    edaU1 CentOS 6.5
    compile by c++11
compile:
    type make to compile
run:
    ./FM [inputfile] [outputfile]
remove executable:
    make clean